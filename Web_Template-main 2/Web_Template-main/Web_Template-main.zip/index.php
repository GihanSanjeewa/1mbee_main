<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>1Mbee.lk</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--SWIPER JS-->
      <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
      <!-- ICONSCOUT CDN-->
      <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

   </head>
   
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <div class="wrapper">
      <!-- end loader -->
      <div class="sidebar">
         <!-- Sidebar  -->
         <nav id="sidebar">
            <div id="dismiss">
               <i class="fa fa-arrow-left"></i>
            </div>
            <ul class="list-unstyled components">
               <li class="active"> <a href="#">Home</a> </li>
               <li><a href="#about">About </a> </li>
               <li><a href="#work">Service</a> </li>
               <li><a href="#contact">Contact </a> </li>
            </ul>
         </nav>
      </div>
      <div id="content">
         <!-- header -->
         <header>
            <!-- header inner -->
            <div class="header">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                           <div class="center-desk">
                              <div class="logo">                                
                                 <a  href="index.html"><img id="imgl" src="images/7gQj.gif" alt="unavilable" /></a>
                                 <h1>Explore <br><span>The New </span><br> World</h1> 
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <ul class="btn">                           
                           
                           <li><button type="button" id="sidebarCollapse">
                              <img src="images/80al.gif" alt="#" />
                              </button>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <!-- end header inner -->
         <!-- end header -->
         <!-- banner -->
         <div id="myCarousel" class="carousel slide banner_main" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
               <li data-target="#myCarousel" data-slide-to="1"></li>
               <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container-fluid">
                     <div class="carousel-caption">
                        <div class="row">
                           <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                              <div class="text-bg">
                                 <h1>Web<br> Application <br>Development</h1>                                
                                 <p>Web apps don't require users to download them, making them easy to access while eliminating the need for end-user maintenance and hard drive capacity </p>
                                 
                              </div>
                           </div>
                           <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
                              <div class="images_box">
                                 <figure><img src="images/web_development.gif"></figure>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container-fluid ">
                     <div class="carousel-caption">
                        <div class="row">
                           <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                              <div class="text-bg">
                                 <h1>Desktop<br> Application <br>Development</h1>
                                 <p>A great desktop application is powerful and, at the same time, simple. Through carefully balanced feature selection and presentation, you can achieve both power and simplicity. </p>
                                 
                              </div>
                           </div>
                           <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
                              <div class="images_box">
                                 <figure><img src="images/programer.gif"></figure>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container-fluid">
                     <div class="carousel-caption ">
                        <div class="row">
                           <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                              <div class="text-bg">
                                 <h1>UI / UX<br>Designing</h1>
                                 <p>UI/UX designers are responsible for overall user satisfaction with a product. Their priority is to continually look for ways to improve the product experience, even for bestselling products that have been on the market for years. They may do this by making the product faster, easier to use, or more fun.</p>
                                
                              </div>
                           </div>
                           <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
                              <div class="images_box">
                                 <figure><img src="images/Featured-Image.gif"></figure>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
            <i class="fa fa-long-arrow-left" aria-hidden="true"></i>
            </a>
            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            </a>
         </div>
         <!-- end banner -->
         <!-- about -->
         <div id="about"  class="about">
            <div class="container-fluid">
               <div class="row d_flex">
                  <div class="col-md-5">
                     <div class="about_img">
                        <figure><img src="images/se4.gif" alt="#"/></figure>
                     </div>
                  </div>
                  <div class="col-md-7">
                     <div class="titlepage">
                        <h2>About <span class="blu">1MBee</span></h2>
                        <p>Established on 25/02/2023, <br>
                           Engineers with excelent abilities are currently working in our company.
                           We will do our best to import and provide reliable excelent service to create any software required by the clients.
                           To know our services see the "SERVICES" section.
                         </p>
                     
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>

         <!-- end about -->
         <!-- choose  section -->
         <div class="choose ">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="titlepage">
                        <h2>Why <span class="blu"> Choose Us</span></h2>
                     </div>
                  </div>
               </div>
            </div>
            <div class="choose_bg">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="row">
                           <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 padding_right0">
                              <ul class="easy">
                                 <li><a href="#">Easy to cutomize</a></li>
                                 <li><a href="#">More flexible</a></li>
                                 <li><a href="#">Clean mode</a></li>
                                 <li><a href="#">Ratinaready</a></li>
                              </ul>
                           </div>
                           <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 padding_right0">
                             <img src="images/choose3.webp" alt="">
                             <img src="images/choose.webp" alt="">
                           </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 padding_left0">
                              <p id="pchoos">
                                 Made up of a very excellent and talented team, our company is committed to providing the service you need. As we do our best, you can contact us by visiting our office and also by whatsapp and  email.
                                 Do you have any idea about any software, web page you need for your business? Talk to us and we will provide you with excellent designs under constant guidance.
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end choose  section -->
         <!-- work -->
         <div id="work"  class="work">
            <div class="container-fluid">
               <div class="row d_flex">
                  <div class="col-md-7">
                     <div class="titlepage">
                        <h2>What <span class="blu"> WE DID</span></h2>
                        
                        <div class="videosec" id="video1">

                            <video id="video"  loop muted autoplay="autoplay">
                              <source src="images/WhatsApp Video 2023-03-31 at 23.33.33.mp4" type="video/mp4">
                              <source src="mov_bbb.ogg" type="video/ogg">
                              Your browser does not support HTML video.
                            </video> 
                                            
                        </div>

                        
                        
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
         <!-- end work -->
         <!-- request -->
         <div id="contact" class="request">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="titlepage">
                        <h2>Request <span class="white">A call Back</span></h2>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-6">
                     <form id="request" class="main_form" action="mail_handler.php" method="post">
                        <div class="row">
                           <div class="col-md-12 ">
                              <input class="contactus" placeholder="Full Name" type="type" name="Full_Name" required> 
                           </div>
                           <div class="col-md-12">
                              <input class="contactus" placeholder="Email" type="type" name="Email" required> 
                           </div>
                           <div class="col-md-12">
                              <input class="contactus" placeholder="Phone Number" type="type" name="Phone_Number" required>                          
                           </div>
                           <div class="col-md-12">
                              <textarea class="textarea"  type="type" name="message"  required>Message </textarea>
                           </div>
                           <div class="col-md-12">
                              <button class="send_btn" type="submit" name="submit" value="Submit" onclick="alert('Thanks For Choosing Us')">Send</button>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div class="col-md-6">
                     <div id="map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3956.051618278565!2d80.29309130000001!3d7.459542000000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae33b609c8e18cf%3A0xda6ae938bd03a3e5!2sSathsara%20Book%20Shop%20%26Communication!5e0!3m2!1sen!2slk!4v1678188477259!5m2!1sen!2slk" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end request -->
         <!--  footer -->
         <footer>
            <div class="footer">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                        <div class="row">
                           <div class="col-md-8 col-sm-6">
                              <div class="address">
                                 <h3>Address </h3>
                              </div>
                              <ul class="location_icon">
                                 <li>1mbee SOLUTIONS,<br> School Lane,<br> Uhumeeya, <br>Kurunegala,<br> Sri lanka </li>
                              </ul>
                           </div>
                           <div class="col-md-4 col-sm-6">
                             <!-- add another section here  -->
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                        <div class="row">
                           <div class="col-md-5 col-sm-6">
                              <div class="address">
                                 <h3>Follow Us</h3>
                              </div>
                              <ul class="social_icon">
                                 <li><a href="https://web.facebook.com/profile.php?id=100090838843567">Facebook <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                 <li><a href="https://www.linkedin.com/in/1mbee-solutions-514331269"> Linkedin<i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
                                 <li><a href="https://www.youtube.com/@1mbee"> Youtube<i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="copyright">
                  <div class="container">
                     <div class="row">
                        <div class="col-md-12">
                           <p>Copyright  All Right Reserved By 1mBee PVT(LTD)</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </footer>
         <!-- end footer -->
      </div>
      <div class="overlay"></div>
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script type="text/javascript">
         $(document).ready(function() {
             $("#sidebar").mCustomScrollbar({
                 theme: "minimal"
             });
         
             $('#dismiss, .overlay').on('click', function() {
                 $('#sidebar').removeClass('active');
                 $('.overlay').removeClass('active');
             });
         
             $('#sidebarCollapse').on('click', function() {
                 $('#sidebar').addClass('active');
                 $('.overlay').addClass('active');
                 $('.collapse.in').toggleClass('in');
                 $('a[aria-expanded=true]').attr('aria-expanded', 'false');
             });
         });
      </script>

      


      <script>
         $(document).ready(function() {
             $(".fancybox").fancybox({
                 openEffect: "none",
                 closeEffect: "none"
             });
         
             $(".zoom").hover(function() {    
                 $(this).addClass('transition');
             }, function() {
         
                 $(this).removeClass('transition');
             });
         });
      </script>

      <script>
         // This example adds a marker to indicate the position
       
         function initMap() {
           var map = new google.maps.Map(document.getElementById('map'), {
             zoom: 11,
             center: {
               lat: 40.645037,
               lng: -73.880224
             }
           });
         
           var image = 'images/maps-and-flags.png';
           var beachMarker = new google.maps.Marker({
             position: {
               lat: 40.645037,
               lng: -73.880224
             },
             map: map,
             icon: image
           });
         }
      </script>


<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>


<script>
    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 20,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },

        //when windows width is >= 600px
        breakpoints: {
            600: {
                slidesPerView: 4
            }
        }
    });
</script>

   </body>
</html>

